// 'use strict';
// const AWS = require('aws-sdk');
// // AWS.config.update({region: 'eu-west-1'});

// const db = new AWS.DynamoDB.DocumentClient({
//   region: 'eu-west-1',
// });

// const headers = {
//   'Access-Control-Allow-Origin': '*',
//   'Access-Control-Allow-Credentials': true,
// };

// const dynamo = {
//   put: async data => {
//     const params = {
//       TableName: 'beta-keys',
//       Item: data,
//     }

//     const res = await db.put(params).promise();
//     return res;
//   },

//   get: async keys => {
//     const params = {
//       TableName: 'beta-keys',
//       Key: keys,
//     }

//     const x = await db.get(params).promise();
//     return x.Item;
//   }
// }

// module.exports.afterFileUpload = async (event, context, callback) => {
//   const input = JSON.parse(event.body);

//   const identity = event.Records[0].userIdentity;
//   const s3 = event.Records[0].s3;

//   const result = await dynamo.put({
//     'userId': {S: identity.principalId},
//     'imgKey': {S: s3}
//   });

//   return {
//     headers,
//     statusCode: 200,
//     body: JSON.stringify(
//       {
//         message: result,
//         input: event,
//       },
//       null,
//       2
//     ),
//   };

//   // Use this code if you don't use the http event with the LAMBDA-PROXY integration
//   // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
// };

'use strict';

const uuid = require('uuid');
const AWS = require('aws-sdk'); 

AWS.config.setPromisesDependency(require('bluebird'));

const dynamoDb = new AWS.DynamoDB.DocumentClient();

module.exports.submit = (event, context, callback) => {
  const requestBody = JSON.parse(event.body);
  const fullname = requestBody.fullname;
  const email = requestBody.email;
  const experience = requestBody.experience;

  if (typeof fullname !== 'string' || typeof email !== 'string' || typeof experience !== 'number') {
    console.error('Validation Failed');
    callback(new Error('Couldn\'t submit candidate because of validation errors.'));
    return;
  }

  submitCandidateP(candidateInfo(fullname, email, experience))
    .then(res => {
      callback(null, {
        statusCode: 200,
        body: JSON.stringify({
          message: `Sucessfully submitted candidate with email ${email}`,
          candidateId: res.id
        })
      });
    })
    .catch(err => {
      console.log(err);
      callback(null, {
        statusCode: 500,
        body: JSON.stringify({
          message: `Unable to submit candidate with email ${email}`
        })
      })
    });
};


const submitCandidateP = candidate => {
  console.log('Submitting candidate');
  const candidateInfo = {
    TableName: 'test-table',
    Item: candidate,
  };
  return dynamoDb.put(candidateInfo).promise()
    .then(res => candidate);
};

const candidateInfo = (fullname, email, experience) => {
  const timestamp = new Date().getTime();
  return {
    id: uuid.v1(),
    fullname: fullname,
    email: email,
    experience: experience,
    submittedAt: timestamp,
    updatedAt: timestamp,
  };
};
